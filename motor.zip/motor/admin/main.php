<?php

?>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <h1>INSOTEL Motor</h1>
    <h4>Usar el plugin de reservas de INSOTEL MARINE GROUP es tan sencillo como colocar el siguiente shortcode en el lugar de tu web donde quieras que se muestre:<h4>
            <div class="container text-bg-light p-5 shadow w-100 h-100">
                <div class="row">
                    <div class="col">
                        <div class="w-100 border-1">SHORTCODES</div>
                        <div class="w-100 border-1">[insotel_motor]</div>
                        <div class="w-100 border-1">[insotel_motor_servicios]</div>
                    </div>
                    <div class="col">
                        <div class="w-100 border-1">PARAMETROS DE SHORTCODES</div>
                        <div class="w-100 border-1">no tiene parametros</div>
                        <div class="w-100 border-1">[id_servicio="1006" tipo_servicio="EXPERIENCIAS" tipo_calendario="single"]</div>
                    </div>
                </div>
            </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>